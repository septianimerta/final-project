import os

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///sizes.db")


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":

        # TODO: Add the user's entry into the database
        weight = request.form.get("weight")
        height = request.form.get("height")
        db.execute("INSERT INTO sizes (weight, height) VALUES(?, ?)", weight, height)

        return redirect("/")

    else:
        size = db.execute("SELECT * FROM sizes")
        return render_template("index.html", size=size)

# TODO: Display size recommendation column in the database on index.html


@app.route('/')
def index2():
    cell = db.execute("SELECT size FROM sizes WHERE id = 1")[0]["size"]
    size = db.execute("SELECT * FROM sizes")
    return render_template("template.html", cell=cell, size=size)
